package ejerecicios;

import java.util.Optional;
import java.util.stream.Stream;

public class Ejercicio1 {
	/*Dada la siguiente definici�n recursiva de la funci�n f (que toma como entrada 3
n�meros enteros positivos y devuelve una cadena):

siendo + un operador que representa la concatenaci�n de cadenas, y toString(i) un m�todo
que devuelve una cadena a partir de un entero. Al llevar a cabo la implementaci�n, para
el tratamiento de cadenas se recomienda hacer uso de String.format.

Proporcione una soluci�n iterativa usando while, una recursiva no
final, una recursiva final, y una en notaci�n funcional*/
	
public static String fIt (Integer a, Integer b, Integer c) {
	String ac = "";
	
	while(a+b+c > 3) {
		if(a<3 && b<3 && c<3) {
			ac =  ac + "(" + Integer.toString(a*b*c) +")";
			break;
		}
	
	if(a<5 || b<5 || c<5) {
		
		ac =  ac + "(" + Integer.toString(a+b+c) +")";
		
			break;
	}
	if (a%2==0 && b%2==0 && c%2==0 ) {
	
		ac = ac + Integer.toString(a*b*c);
		a= a/2;
		b= b-2;
		c= c/2;
	}else {
		
		ac =  ac + Integer.toString(a+b+c);
		a= a/3;
		b= b-3;
		c= c/3;
		}
	}

	return ac;
}
// Recursivo no final
public static String fRNF(Integer a, Integer b, Integer c) {
	String ac ="";
	
	if(a<3 && b<3 && c<3) {
		return  ac + "(" + Integer.toString(a*b*c) +")";
		
	}

	if(a<5 || b<5 || c<5) {
	
		return   ac +"(" + Integer.toString(a+b+c) +")";
	
	}

	if (a%2==0 && b%2==0 && c%2==0 ) {
     
		ac =   Integer.toString(a*b*c) + fRNF(a/2,b-2,c/2);
	}else {
	
		ac =  Integer.toString(a+b+c) + fRNF(a/3,b-3,c/3) ;
	}
	
	return ac;
	
	
	
}

//Recursivo final

public static String fR(Integer a, Integer b, Integer c) {
	
	return RAux(a,b,c, "");
}

public static String RAux(Integer a, Integer b, Integer c, String ac) {
	// TODO Auto-generated method stub
	if(a<3 && b<3 && c<3) {
		 ac = ac + "(" + Integer.toString(a*b*c) +")";
		return   ac;
		
	}

if(a<5 || b<5 || c<5) {
	
	return  ac + "(" + Integer.toString(a+b+c) +")";
	
}
if (a%2==0 && b%2==0 && c%2==0 ) {

	return RAux(a/2,b-2,c/2, ac + Integer.toString(a*b*c));
}else {
	
	return RAux(a/3,b-3,c/3, ac + Integer.toString(a+b+c));
}
	
}

//funcional

public static String fF(Integer a, Integer b, Integer c) {
	ej1 r =  ej1.of(a, b, c, "");
	//falla
/*	return Stream.iterate(ej1.noBase(a, b, c, ac),
			t -> ej1.casoB(a, b, c) ? t + "(" + Integer.toString(a*b*c) +")" 
					: ej1.casoA(a, b, c) ? t + "(" + Integer.toString(a+b+c) +")" 
							: t).collect(null).toString(); */
	 Optional<ej1> st= Stream.iterate( r, t-> t.next())
			.filter(x->r.esCB(x)).findFirst();
	 
			return		st.isPresent()? casoBase(st.get()): "-1";
}


public static String casoBase( ej1 r) {
	String res="";

	if(r.a()<3 && r.b()<3 && r.c()<3){
		res = r.s() + "(" + Integer.toString(r.a()*r.b()*r.c()) +")";
		
	}else if (r.a()<5 || r.b()<5 || r.c()<5) {
		res = r.s() + "(" + Integer.toString(r.a()+r.b()+r.c()) +")";
	}
	return res;
}

public static record  ej1(Integer a, Integer b, Integer c, String s) {
	public static ej1 of(Integer a, Integer b, Integer c, String s) {
		return new ej1(a, b, c, s);
	}
	
	
	public ej1 next() {
		ej1 res;
		if (a%2==0 && b%2==0 && c%2==0 ) {
			
			res= ej1.of( a/2, b-2, c/2, s() + Integer.toString(a*b*c)) ;
		}else {
			
			res= ej1.of(a/3, b-3, c/3,s() +Integer.toString(a+b+c));
		}
		return res;
	}
	
	
	public Boolean esCB(ej1 r) {
		Boolean b = (r.a<3 && r.b<3 && r.c<3) || (r.a<5 || r.b<5 || r.c<5);
		
		return b;
	}
	
	
} 


}
