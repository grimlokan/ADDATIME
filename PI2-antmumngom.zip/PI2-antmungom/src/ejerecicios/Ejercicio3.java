package ejerecicios;

import java.util.List;

import us.lsi.common.IntegerSet;

public class Ejercicio3 {
 /*
  * Dada una lista de enteros ordenada de mayor a menor, dise�ar un algoritmo que
devuelva un conjunto que incluya los elementos de dicha lista cuyo valor se encuentre en
un rango [a, b) dado (siendo a y b de tipo entero). Para trabajar con conjuntos, haga uso
del tipo IntegerSet del repositorio.

proporcione una soluci�n recursiva. BUSQUEDA BINARIA recursividad multiple*/
	
	//comparaci�n a partir de intervalo a intervalo 
	
	public static IntegerSet ej3(List<Integer> ls, Integer a, Integer b) {
		
		return ej3Aux(ls,IntegerSet.empty(),0,ls.size()-1,a,b);
	}
	public static IntegerSet ej3Aux(List<Integer> ls,IntegerSet res, Integer inC, Integer inF, Integer start, Integer end) {
		if((inF-inC)==1) {
			res = casobase(ls,res,inC,inF,start,end);
		}else {
			Integer pivot=(inC+inF)/2;
			IntegerSet a=ej3Aux(ls,res,inC,pivot,start,end);
		    IntegerSet b=ej3Aux(ls,res,pivot,inF,start,end);
		    
		    res = res.union(a.union(b));
		    
		}
		return res;
	}
	
	public static IntegerSet casobase(List<Integer> ls,IntegerSet res, Integer inC, Integer inF, Integer start, Integer end) {
		// TODO Auto-generated method stub
		
			if(end>ls.get(inC) && ls.get(inC)>=start) {
				res.add(ls.get(inC));
			}
			if(end>ls.get(inF) && ls.get(inF)>=start) {
				res.add(ls.get(inF));
			}
		
		
		return res;
	}
	
	}
	 

	

