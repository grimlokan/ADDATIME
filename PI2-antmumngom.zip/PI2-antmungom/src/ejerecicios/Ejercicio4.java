package ejerecicios;

import java.util.HashMap;
import java.util.Map;

public class Ejercicio4 {
	/*
	 * Dise�ar un algoritmo recursivo, con y sin memoria, y posteriormente encontrar un
algoritmo iterativo que calcule los valores de la recurrencia fibonacci 
fn = 2*fn-1 + 4*fn-2 + 6*fn-3, f2=6, f1=4, f0=2
proporcione una soluci�n recursiva sin memoria, otra recursiva
con memoria (map), y otra iterativa.
*/
	//sin memoria
	public static Long ej4RSM(Integer a) {
		Long res = 0L;
		if(a==0L) {
			res= 2L;
		}else if(a==1L) {
			res= 4L;
			
		}else if(a==2L) {
			
			res = 6L;
			
		}else {
			
			res= 2*ej4RSM(a-1)+4*ej4RSM(a-2)+6*ej4RSM(a-3);
			
		}
		
		
		return res;
	}
	//con memoria
	public static Long ej4RCM(Integer a) {
		
		return ej4RCMAux(a, new HashMap<>());
	}
	
	public static Long ej4RCMAux(Integer a, Map<Integer,Long> m){
		Long res = 0L;
		if(m.containsKey(a)){
			return m.get(a);
		}else if(a==0L) {
			res= 2L;
			m.put(a, res);
		}else if(a==1L) {
			res= 4L;
			m.put(a, res);
		}else if(a==2L) {
			
			res = 6L;
			m.put(a, res);
		}else {
			
			res= 2*ej4RCMAux(a-1,m)+4*ej4RCMAux(a-2,m)+6*ej4RCMAux(a-3,m);
			m.put(a,res);
		}
		
		
		return res;
		
	}
	//Iterativo
	public static Long ej4It(Integer a) {
		Long res=0L;
		Map<Integer,Long> m = new HashMap<>();
		
		for(int na=0 ; na<=a; na++) {
		
		if(na==0L) {
			res= 2L;
			m.put(na, res);
		}else if(na==1L) {
			res= 4L;
			m.put(na, res);
		}else if(na==2L) {
			
			res = 6L;
			m.put(na, res);
		}else {
			
			res= 2*m.get(na-1)+4*m.get(na-2)+6*m.get(na-3);
			m.put(na,res);
		}
		
	}
		return res;
		}
	
	}


