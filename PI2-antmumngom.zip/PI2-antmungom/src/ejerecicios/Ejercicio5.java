package ejerecicios;

import java.util.HashMap;
import java.util.Map;

import us.lsi.common.IntTrio;
import us.lsi.common.Trio;

public class Ejercicio5 {
	/*
	 *Dise�ar un algoritmo recursivo, con y sin memoria, y posteriormente encontrar un
algoritmo iterativo para la siguiente definici�n: 
siendo a, b y c n�meros enteros positivos
 
 a+b^2+ 2*c   para    a<3 o b<3 o c<3
 
 g(a-1, b/2, c/2) + g(a-3, b/3,c/3) para a es multiplo b
 
 g(a/3,b-3,c-3) + g(a/2,b-2,c-2) en otro caso
proporcione una soluci�n recursiva sin memoria, otra recursiva
con memoria (map), y otra iterativa.
*/
	//recursivo sin memoria
	public static Integer ej5RSM(Integer a, Integer b, Integer c) {
		Integer res= 0 ;
		if(a<3 || b<3 || c<3) {
			res= a+b*b+ 2*c;
		}else if(a%b==0) {
			res= ej5RSM(a-1, b/2, c/2) + ej5RSM(a-3, b/3,c/3);
		}else {
			res= ej5RSM(a/3, b-3, c-3) + ej5RSM(a/2, b-2,c-2);
		}
		
		return res;
	}
	//recursivo con memoria
	public static Integer ej5RCM(Integer a, Integer b, Integer c) {
		
		return ej5RCMAux(a,b,c, new HashMap<>());
	}
	
	public static Integer ej5RCMAux(Integer a, Integer b, Integer c, Map<IntTrio,Integer> m) {
		Integer res= 0 ;
		if(m.containsKey(IntTrio.of(a, b, c))){
			return m.get(IntTrio.of(a, b, c));
		}else {
		if(a<3 || b<3 || c<3) {
			res= a+b*b+ 2*c;
			m.put(IntTrio.of(a, b, c),res);
			return res;
		}
		if(a%b==0) {
			res= ej5RCMAux(a-1, b/2, c/2,m) + ej5RCMAux(a-3, b/3,c/3,m);
		}else {
			res= ej5RCMAux(a/3, b-3, c-3,m) + ej5RCMAux(a/2, b-2,c-2,m);
			}
		}
		return res;
	}
	//iterativo
	public static Integer ej5It(Integer a, Integer b, Integer c) {
	Integer res= 0 ;
	Map<IntTrio,Integer> m = new HashMap<>();
	int i = 0;
	
	
	if(m.containsKey(IntTrio.of(a, b, c))){
		return m.get(IntTrio.of(a, b, c));
	}
	while(i<=a) {
		int j = 0;
		 	while(j<=b) {
		 		int k=0;
		 			while(k<=c){
				
		 				if(i<3 || j<3 || k<3) {
		 					res= i+(j*j)+ 2*k;
		 				}else if(i%j==0) {
		 					res=m.get(IntTrio.of(i-1, j/2, k/2)) +
		 						m.get(IntTrio.of(i-3, j/3,k/3));;
							//a-1, b/2, c/2 + a-3, b/3,c/3;
					
		 				}else {
		 					res= m.get(IntTrio.of(i/3, j-3, k-3)) + 
		 						 m.get(IntTrio.of(i/2, j-2,k-2));
							//(a/3, b-3, c-3) + (a/2, b-2,c-2);
				 
		 				}
		 				m.put(IntTrio.of(i, j, k), res);
		 				k++;
		 			}
		 			j++;
		 		}
				i++;
			}
		
		return res;
	}
	
}
