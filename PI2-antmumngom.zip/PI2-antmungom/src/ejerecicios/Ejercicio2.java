package ejerecicios;

import java.util.ArrayList;
import java.util.List;

import us.lsi.common.Matrix;
import us.lsi.common.View4;

public class Ejercicio2 {
	/*Dada una matriz de n x n cadena de caracteres (con n=2m; siendo m un n�mero entero
mayor que 0), devolver una lista de cadenas de caracteres que incluya las cadenas que se
forman uniendo las 4 cadenas de las 4 esquinas de la matriz principal, y de cada una de
sus 4 submatrices, y as� sucesivamente hasta llegar a una matriz de 2x2. El orden en el
que se unen las cadenas de las esquinas es: superior izquierda, superior derecha, inferior
izquierda, e inferior derecha.

proporcione una soluci�n recursiva.*/

	
	public static List<String> ej2(Matrix<String> m) {
		
		return ej2Aux(m, new ArrayList<String>());
	}

	public static List<String> ej2Aux(Matrix<String> m, List<String> ls) {
		// TODO Auto-generated method stub
		
		if(m.area() >4) {
			String s = "";
			for(String n :  m.corners()) {
				s= s+n;
			}
			ls.add(s);
			View4<Matrix<String>> v = m.views4();
			ej2Aux(v.a(),ls);
			ej2Aux(v.b(),ls);
			ej2Aux(v.c(),ls);
			ej2Aux(v.d(),ls);
		}else {
			String s2 = "";
			for(String n2: m.corners()) {
				s2=s2+n2;
			}
			ls.add(s2);
		}
		return ls;
	}
	
	
}
