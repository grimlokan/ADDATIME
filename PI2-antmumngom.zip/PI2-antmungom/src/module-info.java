module PI2 {
	requires partecomun;
	requires datos_compartidos;
	requires java.base;
}