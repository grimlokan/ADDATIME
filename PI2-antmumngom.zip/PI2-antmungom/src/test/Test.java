package test;

import java.util.ArrayList;
import java.util.List;

import ejerecicios.Ejercicio1;
import ejerecicios.Ejercicio5;
import ejerecicios.Ejercicio3;
import ejerecicios.Ejercicio4;
import ejerecicios.Ejercicio2;
import us.lsi.common.Files2;
import us.lsi.common.Matrix;

public class Test {

	public static void test1() {
		List<String> filas = Files2.linesFromFile("./ficheros/PI2Ej1DatosEntrada.txt");
		System.out.println("##################################################");
    	System.out.println("#                   Ejercicio 1                  #");
    	System.out.println("#         ficheros/PI2Ej1DatosEntrada.txt        #");
    	System.out.println("##################################################");
    	for (String linea : filas) {
    		System.out.println("Entrada"+"["+ linea +"]");
    		String[] partes = linea.split(",");
			Integer a = Integer.parseInt(partes[0]);
			Integer b = Integer.parseInt(partes[1]);
			Integer c = Integer.parseInt(partes[2]);
			System.out.println(String.format("Recursivo no final: %s", Ejercicio1.fRNF(a, b, c)));
			System.out.println(String.format("Iterativo:          %s", Ejercicio1.fIt(a, b, c)));
			System.out.println(String.format("Recursivo final:    %s", Ejercicio1.fR(a, b, c)));
			System.out.println(String.format("Funcional:          %s", Ejercicio1.fF(a, b, c)));
			}
			 
	
    	System.out.println("##################################################");
	}
	public static void test2() {
		List<String> filas = Files2.linesFromFile("./ficheros/PI2Ej2DatosEntrada1.txt");// FICHERO 1
		//List<String> filas = Files2.linesFromFile("./ficheros/PI2Ej2DatosEntrada2.txt");// FICHERO 2
		System.out.println("##################################################");
    	System.out.println("#                   Ejercicio 2                  #");
    	//System.out.println("#         ficheros/PI2Ej2DatosEntrada1.txt       #");
    	System.out.println("#         ficheros/PI2Ej2DatosEntrada2.txt      #");
    	System.out.println("##################################################");
    	//creo una lista de listas que mastarde se convertir� en una matriz
    	List<List<String>> f2 = new ArrayList<>();
    	for(String linea : filas ) {
    		// lista que se crea a partir del array de String
    		List<String> ls = new ArrayList<>();
    		String[] partes = linea.split(" ");
    		for(String parte : partes) {
    			ls.add(parte);
    		}
    		//tras  terminar la lista se a�ade a la lista de listas
    		f2.add(ls);
    	}
    	System.out.println("Entrada : "+ f2);
    	Integer tam= f2.size();
    	String[][] mdata = new String [tam][tam];
    	for(int i=0;i<tam;i++) {
    		for(int j=0;j<tam;j++) {
    			String a= f2.get(i).get(j);
    			
    			mdata[i][j]=a;
    			}
    		}
    	Matrix<String> m =Matrix.of(mdata);
    	System.out.println(String.format("Recursivo :    %s", Ejercicio2.ej2(m)));
    	
    	System.out.println("##################################################");
	}
	public static void test3() {
		List<String> filas = Files2.linesFromFile("./ficheros/PI2Ej3DatosEntrada.txt");
		System.out.println("##################################################");
    	System.out.println("#                   Ejercicio 3                  #");
    	System.out.println("#         ficheros/PI2Ej3DatosEntrada.txt        #");
    	System.out.println("##################################################");
    	for (String linea: filas) {
    		String [] partes = linea.split("#");
    		String [] partes2 = partes[1].split(",");
    		String [] partes3 = partes[0].split(",");
    		Integer a = Integer.parseInt(partes2[0]);
    		Integer b = Integer.parseInt(partes2[1]);
    		List<Integer> ls = new ArrayList<>();
    		for(String parte : partes3) {
    			Integer z = Integer.parseInt(parte);
    			ls.add(z);
    		}
    		System.out.println("Entrada: " + ls);
    		System.out.println("Rango: " + "[" + a + "," + b+ ")");
    		System.out.println("Recursivo Multiple: " + Ejercicio3.ej3(ls, a, b) );
    		
    	}
    	
    	
    	System.out.println("##################################################");
	}
	public static void test4() {
		List<String> filas = Files2.linesFromFile("./ficheros/PI2Ej4DatosEntrada.txt");
		System.out.println("##################################################");
    	System.out.println("#                   Ejercicio 4                  #");
    	System.out.println("#         ficheros/PI2Ej4DatosEntrada.txt        #");
    	System.out.println("##################################################");
    	for (String linea : filas) {
    		System.out.println("Entrada (a,b,c): "+"("+ linea +")");
    		String[] partes = linea.split("n=");
			Integer a = Integer.parseInt(partes[1]);
			System.out.println(String.format("Recursivo Sin Mem: %s", Ejercicio4.ej4RSM(a)));
			System.out.println(String.format("Recursivo Con Mem: %s", Ejercicio4.ej4RCM(a)));
			System.out.println(String.format("Iterativo:         %s", Ejercicio4.ej4It(a)));
			}
    	System.out.println("##################################################");
	}
	public static void test5() {
		List<String> filas = Files2.linesFromFile("./ficheros/PI2Ej5DatosEntrada.txt");
		System.out.println("##################################################");
    	System.out.println("#                   Ejercicio 5                  #");
    	System.out.println("#         ficheros/PI2Ej5DatosEntrada.txt        #");
    	System.out.println("##################################################");
    	for (String linea : filas) {
    		System.out.println("Entrada (a,b,c): "+"("+ linea +")");
    		String[] partes = linea.split(",");
			Integer a = Integer.parseInt(partes[0]);
			Integer b = Integer.parseInt(partes[1]);
			Integer c = Integer.parseInt(partes[2]);
			System.out.println(String.format("Recursivo Sin Mem: %s", Ejercicio5.ej5RSM(a, b, c)));
			System.out.println(String.format("Recursivo Con Mem: %s", Ejercicio5.ej5RCM(a, b, c)));
			System.out.println(String.format("Iterativo:         %s", Ejercicio5.ej5It(a, b, c)));
			}
    	System.out.println("##################################################");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//test1();//
		//test2();//
		test3();//
		//test4();//
		//test5();//done
	}

}
