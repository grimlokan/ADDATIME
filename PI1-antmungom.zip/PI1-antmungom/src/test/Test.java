package test;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

import ejercicios.Ejercicio1;
import ejercicios.Ejercicio2;
import ejercicios.Ejercicio3;
import ejercicios.Ejercicio4;
import us.lsi.common.Files2;

public class Test {
	public static void test1() {
		// El predicado sobre String devuelve cierto si dicho String contiene alguna vocal abierta (es decir, a, e � o)
		// El predicado sobre Integer devuelve cierto si ese entero es par
		// La funci�n String -> Integer devuelve la longitud de la cadena 
		List<String> filas = Files2.linesFromFile("./ficheros/PI1E1_DatosEntrada.txt");
		Predicate<String> pS = x -> x.contains("a") || x.contains("e")|| x.contains("o");// El predicado sobre String devuelve cierto si dicho String contiene alguna vocal abierta (es decir, a, e � o)			
		Predicate<Integer> pI = x ->x%2==0; // El predicado sobre Integer devuelve cierto si ese entero es par   					 		
		Function<String, Integer> f = x -> x.length();// La funci�n String -> Integer devuelve la longitud de la cadena

		System.out.println("##################################################");
    	System.out.println("#                   Ejercicio 1                  #");
    	System.out.println("#         ficheros/PI1E1_DatosEntrada.txt        #");
    	System.out.println("##################################################");
    	for (String linea : filas) {
    		List<String> ls = new ArrayList<String>();
    		if(!linea.startsWith("//") || linea.isEmpty()) {
    		System.out.println("Entrada"+"["+ linea +"]");
    		String[] partes = linea.split(", ");
			 for (String parte : partes) {       
		       ls.add(parte);
			 }
			 System.out.println("Iterativo: " + Ejercicio1.ejercicio1It(ls, pS, pI, f));
		      System.out.println("Recursivo: " + Ejercicio1.ejercicio1RF(ls, pS, pI, f));
		      System.out.println("funcional: " + Ejercicio1.ejercicio1F(ls, pS, pI, f));
    		}
    	}
    	System.out.println("##################################################");
	}

	public static void test2() {
		//List<String> filas = Files2.linesFromFile("./ficheros/PI1E2_DatosEntrada1.txt");
		List<String> filas = Files2.linesFromFile("./ficheros/PI1E2_DatosEntrada2.txt");
		List<List<String>> ls = new ArrayList<List<String>>();
		for (String f: filas) {
			if(f.isEmpty()) {
				ls.add(new ArrayList<String>());
			}
			else {
				ls.add(separarLineas(f));
			}
			}
		
		
		
		System.out.println("##################################################");
    	System.out.println("#                   Ejercicio 2                  #");
    	System.out.println("#         ficheros/PI1E2_DatosEntrada2.txt       #");
    	System.out.println("##################################################");
    	
    	System.out.println("Entrada" + ls);
    	System.out.println("Iterativo (While): " + Ejercicio2.ejercicio2It(ls));
    	System.out.println("funcional: " + Ejercicio2.ejercicio2It(ls));
    	System.out.println("Recursivo: " + Ejercicio2.ejercicio2R(ls));// arreglar
  
    	System.out.println("##################################################");
	}
	
	private static List<String> separarLineas (String l){
		List<String> res =  new ArrayList<String>();
		for (String s:l.split(",")) {
			res.add(s);
		}
		return res;
		
	}
	private static List<Integer> separarLineas2(String l){
		List<Integer> res =  new ArrayList<Integer>();
		for (String s:l.split(",")) {
			res.add(Integer.parseInt(s));
		}
		return res;
		
	}
	//lectura del fichero
	/*public static List<List<String>> lecturaFichero(String f){
		List<List<String>> ls = new ArrayList<List<String>>();
		
		List<String> aux= Files2.linesFromFile(f);
		
		for (String linea: aux) {
			if(linea.isEmpty()) {
				ls.add(new ArrayList<String>());
			}
			else {
				ls.add(separarLineas(linea));
			}
		}
		return ls;
	}
	
	*/

	
	
	public static void test3() {
		List<String> filas = Files2.linesFromFile("./ficheros/PI1E3_DatosEntrada.txt");
		List<List<Integer>> ls = new ArrayList<List<Integer>>();
		Integer v1 = 0;
		Integer v2 =0 ;
		for(String fila : filas) {
			if(fila.isEmpty()) {
				ls.add(new ArrayList<Integer>());
			}
			else {
				ls.add(separarLineas2(fila));
			}	
		
		}
		System.out.println("##################################################");
    	System.out.println("#                   Ejercicio 3                  #");
    	System.out.println("#         ficheros/PI1E3_DatosEntrada.txt        #");
    	System.out.println("##################################################");
    	for(List<Integer> l : ls) {
    		v1=l.get(0);
    		v2=l.get(1);
    	System.out.println("Entrada" + Ejercicio3.Par.of(v1, v2));
    	System.out.println("Iterativo (While): " + Ejercicio3.ejercicio3It(v1,v2));
    	System.out.println("funcional: " + Ejercicio3.ejercicio3(v1,v2));
    	System.out.println("Recursivo: " + Ejercicio3.ejercicio3R(v1,v2));
	
    	}
    	System.out.println("##################################################");
    	}
	public static void test4() {
		List<String> filas = Files2.linesFromFile("./ficheros/PI1E4_DatosEntrada.txt");
		System.out.println("##################################################");
    	System.out.println("#                   Ejercicio 4                  #");
    	System.out.println("#         ficheros/PI1E4_DatosEntrada.txt        #");
    	System.out.println("##################################################");
		
		System.out.println("Iterativo (While): " + Ejercicio4.ejercicio4It(125.0,0.001));
		System.out.println("##################################################");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//test1();
		//test2();
		test3();
		//test4();
	}

}
