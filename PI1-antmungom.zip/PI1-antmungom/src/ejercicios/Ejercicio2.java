package ejercicios;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Ejercicio2 {
	/* Dada una lista de listas Strings, organizarlos por numero de letras (numero de letras son las keys)
	 * public static Map<Integer,List<String>> ejercicio2 (List<List<String>> listas) {
return listas.stream()
.flatMap(lista -> lista.stream())
.collect(Collectors.groupingBy(String::length));*/
	
	public static Map<Integer,List<String>> ejercicio2 (List<List<String>> listas) {
		return listas.stream()
		.flatMap(lista -> lista.stream()).collect(Collectors.groupingBy(String::length));
		
	}
	//iterativa
	public static Map<Integer,List<String>> ejercicio2It (List<List<String>> listas) {
		Map<Integer,List<String>> ac = new HashMap<Integer,List<String>>();
		Integer i = 0;
		while(i<listas.size()) {
			List<String> l = new ArrayList<String>();
			l = listas.get(i);
			for(String cad : l) {
				Integer tam= cad.length();
				if (ac.containsKey(tam)) {
					List<String> mit = ac.get(tam);
					mit.add(cad);
					ac.put(tam, mit);
				}else {
					List<String> mit = new ArrayList<>();
					mit.add(cad);
					ac.put(tam, mit);
				}
			}
			
			i++;
		}
	
		return ac;
	}
	
	//recursiva final
	public static Map<Integer,List<String>> ejercicio2R (List<List<String>> listas){
		
		return  ejercicio2RAux (listas,0, new HashMap<Integer,List<String>>() );
}
	private static Map<Integer, List<String>> ejercicio2RAux(List<List<String>> listas, Integer i, Map<Integer, List<String>> ac) {
		// TODO Auto-generated method stub
		if(i<listas.size()) {
			List<String> mit = listas.get(i);
			Integer tam = mit.get(i).length() ;
			
			for(String cad : mit) {
				if (ac.containsKey(tam)) {
					ac.get(tam);
					mit.add(cad);
					ac.put(tam, mit);
					return ejercicio2RAux(listas, i++, ac);
				}else {
					
					mit.add(cad);
					ac.put(tam, mit);
					return ac;
				}
		
			}
			}
		return ejercicio2RAux(listas, i++, ac);
	}
	

	
		
	
	
}
