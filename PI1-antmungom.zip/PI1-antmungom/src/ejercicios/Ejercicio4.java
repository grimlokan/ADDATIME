package ejercicios;

import java.util.stream.Stream;

public class Ejercicio4 {
/*Dise�e un algoritmo que dados dos n�meros n y e 
 * (con n real positivo mayor que 1 y e real en el intervalo (0,1)), 
 * devuelva un n�mero real que se corresponda con la ra�z c�bica de n con un error menor que e.*/
	
	
	//iterativa (while)
	public static Double ejercicio4It(Double n, Double e) {
		Double a = 0.0;
		Double b= n;
		Double c=b/2;
		
		
		while (a<n) {
			if(Math.pow(c, 3)-n< Math.pow(e,3)) {
				
			}
			
			a++;
		}
		return c;
	}
	//recursiva final
	
	public static record infoF (Double a, Double b) {
		public static infoF of(Double num) {
			return new infoF (0.0,num);
		}
		
		public infoF next(Double n) {
			Double c = (a+ b)/2;
			Double newA= a;
			Double newB= b;
			if(c<n) {
				newA=c;
			}else {
				newB=c;
			}
			return new infoF(newA,newB);
		}
			
	}
	// funcional
	public static Double ejercicio4F(Double n, Double e) {
		Double a = 0.0;
		Double b= n;
		Double c=b/2;
		infoF f= Stream.iterate(infoF.of(n), x ->x.next(n))
				.filter(p->Math.pow(c, 3)-n < Math.pow(e, 3))
				.findFirst().get();
		return f.b();
				}
	
}
