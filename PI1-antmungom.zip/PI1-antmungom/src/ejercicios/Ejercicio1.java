package ejercicios;

import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

public class Ejercicio1 {
/*
 * public static boolean ejercicio1(List<String> ls, Predicate<String> pS,
Predicate<Integer> pI, Function<String,Integer> f){
return ls.stream()
.filter(pS)
.map(f)
.anyMatch(pI);
 * 
 * */
	
	//iterativa
	public static boolean ejercicio1It(List<String> ls, Predicate<String> pS,
			Predicate<Integer> pI, Function<String,Integer> f) { 
		boolean ac= false;
		int i = 0;
		while(i<ls.size()) {
			if(pS.test(ls.get(i)) == true) {
				ac = ac || pI.test(f.apply(ls.get(i)));
			}
					i++;
		}
	
				
		return ac;
	}
	//recursiva final
	public static boolean ejercicio1RF(List<String> ls, Predicate<String> pS,
			Predicate<Integer> pI, Function<String,Integer> f) {
		
		
		return ejercicio1RFAUX(ls,pS,pI,f, 0 ,false);
	}
	public static boolean ejercicio1RFAUX(List<String> ls, Predicate<String> pS, Predicate<Integer> pI,
			Function<String, Integer> f,Integer i, boolean ac) {
		// TODO Auto-generated method stub
		if(i<ls.size()) {
		if(pS.test(ls.get(i)) == true && pI.test(ls.get(i).length()) == true) {
			i++;
			return ejercicio1RFAUX(ls,pS,pI,f, i, true);
		}else {
			i++;
			return ejercicio1RFAUX(ls,pS,pI,f, i, ac);
			}
		}else {
			return ac;
		}
		
	}
	//funcional
	public static boolean ejercicio1F(List<String> ls, Predicate<String> pS,
			Predicate<Integer> pI, Function<String,Integer> f){
			return ls.stream()
			.filter(pS)
			.map(f)
			.anyMatch(pI);
	
		}
	}
