package ejercicios;

import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Ejercicio3 {
/*
 * public static String ejercicio3(Integer a, Integer limit) {
return Stream
.iterate(Par.of(0, a),
t -> t.v1 < limit,
t -> Par.of(t.v1+1, t.v1 % 3 == 1 ? t.v2 : t.v1+t.v2))
.collect(Collectors.toList())
.toString();
}

donde Par es una clase con 2 propiedades enteras v1 y v2, la cual debe implementar como un record.
 */
	public record Par(Integer v1, Integer v2) {
        public Par(Integer v1, Integer v2) {
        	this.v1=v1;
        	this.v2=v2;
        }
		public static Par of(Integer v1, Integer v2) {
			return new Par(v1,v2);
		}
		public Integer getV1() {
			return v1;
		}
		public Integer getV2() {
			return v2;
		}
		public static String String(Integer v1, Integer v2) {
			String s = "[ v1 = " + String.valueOf(v1) + ", v2 = " + String.valueOf(v2) + " ]"; 
			return s;
			
		}
		
		
	 }
	
	//funcional
	public static String ejercicio3(Integer a, Integer limit) {
		return Stream
		.iterate(Par.of(0, a),
		t -> t.v1 < limit,
		t -> Par.of(t.v1+1, t.v1 % 3 == 1 ? t.v2 : t.v1+t.v2))
		.collect(Collectors.toList())
		.toString();
		}
		

	//iterativa
	public static String ejercicio3It(Integer a, Integer limit) {
		
		Integer i =0;
		Integer v2 = a;
		String ac = "";
		
		
		while(i<limit) {
			Integer v1=i;
			if(i%3 == 1) {
				v2=v2+0;
				ac = ac + ", " + Par.String(i,v2);
				
			}else {
				
				v2= v1+v2;
				
				ac = ac + ", " + Par.String(i,v2);	
			}
			i++;
			 
			
		}
		
		return ac;
	}
	//recursiva final
public static String ejercicio3R(Integer a, Integer limit) {
		
		return ejercicio3RAux (a, limit, " ", 0);
	}


	private static String ejercicio3RAux(Integer a, Integer limit, String ac, Integer i) {
		// TODO Auto-generated method stub
		
		Integer v2 = a;
		if(i<limit) {
			Integer v1=i;
			if(i%3 == 1) {
				ac =ac + ", " + Par.String(v1, v2);
				return ejercicio3RAux(a,limit, ac, i++);
				
			}else {
				v2= v1+v2;
				ac = ac + ", " + Par.String(v1, v2);
			}
		}
		
		return ac;
	}
}
