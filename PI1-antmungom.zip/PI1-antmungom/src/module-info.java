module pi1_antmungom {
	requires partecomun;
	requires datos_compartidos;
	requires java.base;
}